package com.orders.controller;

import com.orders.model.ItemDetails;
import com.orders.repository.ItemRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ItemController.class)
class ItemControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ItemRepository mockItemRepository;

    @Test
    void testImportFromExcel() throws Exception {
        // Setup
        // Configure ItemRepository.saveAll(...).
        final List<ItemDetails> itemDetails = Arrays.asList(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.saveAll(Arrays.asList(new ItemDetails(0, "ItemName", 0, 0)))).thenReturn(itemDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v2/import/excel")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
       // verify(mockItemRepository).saveAll(Arrays.asList(new ItemDetails(0, "ItemName", 0, 0)));
    }

    @Test
    void testGetAllItemDetails() throws Exception {
        // Setup
        // Configure ItemRepository.findAll(...).
        final List<ItemDetails> itemDetails = Arrays.asList(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.findAll()).thenReturn(itemDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v2/itemdetails")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testGetAllItemDetails_ItemRepositoryReturnsNoItems() throws Exception {
        // Setup
        when(mockItemRepository.findAll()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v2/itemdetails")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testCreateItemDetail() throws Exception {
        // Setup
        when(mockItemRepository.save(any(ItemDetails.class))).thenReturn(new ItemDetails(0, "ItemName", 0, 0));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/v2/additem")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDeleteItemDetail() throws Exception {
        // Setup
        // Configure ItemRepository.findById(...).
        final Optional<ItemDetails> itemDetails = Optional.of(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.findById(0)).thenReturn(itemDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v2/item/{Orderid}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
        //verify(mockItemRepository).delete(any(ItemDetails.class));
    }

    @Test
    void testDeleteItemDetail_ItemRepositoryFindByIdReturnsAbsent() throws Exception {
        // Setup
        when(mockItemRepository.findById(0)).thenReturn(Optional.empty());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v2/item/{Orderid}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDeleteItemDetail_ThrowsResourceNotFoundException() throws Exception {
        // Setup
        // Configure ItemRepository.findById(...).
        final Optional<ItemDetails> itemDetails = Optional.of(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.findById(0)).thenReturn(itemDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v2/item/{Orderid}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
       // verify(mockItemRepository).delete(any(ItemDetails.class));
    }

    @Test
    void testUpdateItemDetail() throws Exception {
        // Setup
        // Configure ItemRepository.findById(...).
        final Optional<ItemDetails> itemDetails = Optional.of(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.findById(0)).thenReturn(itemDetails);

        when(mockItemRepository.save(any(ItemDetails.class))).thenReturn(new ItemDetails(0, "ItemName", 0, 0));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/v2/item/{Orderid}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUpdateItemDetail_ItemRepositoryFindByIdReturnsAbsent() throws Exception {
        // Setup
        when(mockItemRepository.findById(0)).thenReturn(Optional.empty());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/v2/item/{Orderid}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUpdateItemDetail_ThrowsResourceNotFoundException() throws Exception {
        // Setup
        // Configure ItemRepository.findById(...).
        final Optional<ItemDetails> itemDetails = Optional.of(new ItemDetails(0, "ItemName", 0, 0));
        when(mockItemRepository.findById(0)).thenReturn(itemDetails);

        when(mockItemRepository.save(any(ItemDetails.class))).thenReturn(new ItemDetails(0, "ItemName", 0, 0));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/v2/item/{Orderid}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
