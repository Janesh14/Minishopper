package com.orders.model;

import org.junit.jupiter.api.BeforeEach;

class ItemDetailsTest {

    private ItemDetails itemDetailsUnderTest;

    @BeforeEach
    void setUp() {
       // itemDetailsUnderTest = new ItemDetails(0, "ItemName", 0, 0);
    }
}
