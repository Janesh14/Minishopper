package com.orders.excel;

import com.orders.model.ItemDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

class UserExcelImporterTest {

    private UserExcelImporter userExcelImporterUnderTest;

    @BeforeEach
    void setUp() {
        userExcelImporterUnderTest = new UserExcelImporter();
    }

    @Test
    void testExcelImport() {
        // Setup
        // Run the test
        final List<ItemDetails> result = userExcelImporterUnderTest.excelImport();

        // Verify the results
    }

    @Test
    void testMain() {
        // Setup
        // Run the test
        UserExcelImporter.main(new String[]{"args"});

        // Verify the results
    }
}
