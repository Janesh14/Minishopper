package com.orders.excel;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.orders.model.ItemDetails;

public class UserExcelImporter {
	public List<ItemDetails> excelImport() {
		List<ItemDetails> listItemDetails = new ArrayList<>();
		int Orderid = 0;
		String ItemName = "";
		int Quantity = 0;
		int Price = 0;

		String excelFilePath = "C:\\Users\\2106995\\OneDrive - Cognizant\\Desktop\\ItemDetails.xlsx";

		long start = System.currentTimeMillis();

		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(excelFilePath);
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = firstSheet.iterator();

			while (rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						Orderid = (int) nextCell.getNumericCellValue();

						break;
					case 1:
						ItemName = nextCell.getStringCellValue();

						break;
					case 2:
						Quantity = (int) nextCell.getNumericCellValue();

						break;
					case 3:
						Price = (int) nextCell.getNumericCellValue();

						break;

					}

				}

				listItemDetails.add(new ItemDetails(Orderid, ItemName, Quantity, Price));
			}

			workbook.close();
			long end = System.currentTimeMillis();

		} catch (Exception e) {

			e.printStackTrace();
		}

		return listItemDetails;
	}

	public static void main(String[] args) {
		UserExcelImporter us = new UserExcelImporter();
		List<ItemDetails> listItemDetails = us.excelImport();
		for (int itr = 0; itr < listItemDetails.size(); itr++) {

		}
	}
}
