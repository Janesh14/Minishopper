
package com.orders.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import com.sun.istack.NotNull;

@Entity
@Table(name = "ItemDetails")
public class ItemDetails {

	@Id
	@NotNull
	private int Orderid;
	@NotNull
	private String ItemName;
	@NotNull
	private int Quantity;
	@NotNull
	private int Price;
	
	public ItemDetails(int Orderid, String ItemName, int Quantity, int Price) {
		super();
		this.Orderid = Orderid;
		this.ItemName = ItemName;
		this.Quantity = Quantity;
		this.Price = Price;
		
	}
	public ItemDetails() {
		super();
		
	}

	public int getOrderid() {
		return Orderid;
	}

	public void setOrderid(int orderid) {
		Orderid = orderid;
	}

	public String getItemName() {
		return ItemName;
	}

	public void setItemName(String itemName) {
		ItemName = itemName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

}
