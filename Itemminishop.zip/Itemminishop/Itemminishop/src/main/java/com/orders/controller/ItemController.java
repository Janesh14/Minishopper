
package com.orders.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.orders.excel.UserExcelImporter;
import com.orders.exception.ResourceNotFoundException;
import com.orders.model.ItemDetails;

import com.orders.repository.ItemRepository;

@RestController

@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping("/api/v2")
public class ItemController {

	@Autowired
	ItemRepository ItemRepository;
	
	@RequestMapping("/import/excel")
	@ResponseBody
	public String importFromExcel() {
		UserExcelImporter excelImporter=new UserExcelImporter();
		List<ItemDetails> listItemDetails= excelImporter.excelImport();
		ItemRepository.saveAll(listItemDetails);
		return "Import Successfully";
	}

	@GetMapping("/itemdetails")
	public List<ItemDetails> getAllItemDetails() {
		return ItemRepository.findAll();
	}

	@PostMapping("/additem")
	public ItemDetails createItemDetail(@RequestBody ItemDetails ItemDetails) {
		return ItemRepository.save(ItemDetails);
	}

	@DeleteMapping("/item/{Orderid}")
	public Map<String, Boolean> deleteItemDetail(@PathVariable(value = "Orderid") int OrderId)
			throws ResourceNotFoundException {
		ItemDetails ItemDetails = ItemRepository.findById(OrderId)
				.orElseThrow(() -> new ResourceNotFoundException("Item not found for this Order id:: " + OrderId));
		ItemRepository.delete(ItemDetails);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PutMapping("/item/{Orderid}")
	public ResponseEntity<ItemDetails> updateItemDetail(@PathVariable(value = "Orderid") int OrderId,

			@RequestBody ItemDetails ItemDetails) throws ResourceNotFoundException {
		ItemDetails itemDetails = ItemRepository.findById(OrderId)
				.orElseThrow(() -> new ResourceNotFoundException("Item Not found for this order Id::" + OrderId));
		ItemDetails.setItemName(ItemDetails.getItemName());

		final ItemDetails updateItemDetails = ItemRepository.save(ItemDetails);
		return ResponseEntity.ok(updateItemDetails);
	}

}