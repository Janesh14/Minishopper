package com.orders.service;
import org.springframework.http.ResponseEntity;

import com.orders.model.ItemDetails;




public interface ItemService {
	
	ResponseEntity<Object> save(ItemDetails ItemDetails);

	
}
	


