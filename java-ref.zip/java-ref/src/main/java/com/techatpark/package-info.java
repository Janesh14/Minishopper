/**
 * Basic Classes for Practicing Java.
 */
package com.techatpark;
