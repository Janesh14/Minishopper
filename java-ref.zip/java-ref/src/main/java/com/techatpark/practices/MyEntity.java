package com.techatpark.practices;

import org.locationtech.jts.awt.PointShapeFactory;
import org.locationtech.jts.geom.Point;
import java.net.InetAddress;


public record MyEntity(long id, InetAddress theValue) {
}
