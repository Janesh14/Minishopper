package com.techatpark.practices;
import java.net.InetAddress;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.CoordinateXY;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.impl.CoordinateArraySequence;
import org.postgresql.geometric.PGpoint;
import java.net.InetAddress;



public class MyEntityMaker {

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:postgresql://127.0.0.1:5432/postgres", "postgres", "postgres123"
        );
    }


    public void create() throws SQLException {
        Connection connection = getConnection();
        Statement statement;
        try {
            String query = "INSERT INTO public.my_entity (id,the_value) VALUES (4,'192.168.1.0/24')";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Inserted values");
        } catch (Exception e) {
            System.out.println(e);

        }


    }
    public void My_data(int id) throws SQLException {
        Connection connection = getConnection();

        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * FROM my_entity WHERE id = ?";
            preparedStatement = connection.prepareStatement(query);

            // Set the value for the parameter (assuming you have an id variable)
            preparedStatement.setInt(1, id);

            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("id") + "");
                System.out.println(rs.getString("the_value") + "");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }


//    public List<MyEntity> list() throws SQLException {
//        List<MyEntity> myEntities = new ArrayList<>();
//
//        Connection connection = getConnection();
//        PreparedStatement preparedStatement = connection.prepareStatement("SELECT id,the_value from my_entity");
//
//        // Step 3: Execute the query or update query
//        ResultSet rs = preparedStatement.executeQuery();
//
//        // Step 4: Process the ResultSet object.
//        while (rs.next()) {
//            String ipAddressString = rs.getString("the_value");
//            InetAddress inetAddress = createInetAddress(ipAddressString);
//            myEntities.add(new MyEntity(rs.getLong("id"), inetAddress));
//        }
//
//        return myEntities;
//    }
//    private InetAddress createInetAddress(String ipAddress) {
//        try {
//            return InetAddress.getByName(ipAddress);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }

//    /**
//     * create a record.
//     * @param myEntity
//     * @throws SQLException
//     */
//    public void create(final MyEntity myEntity) throws SQLException {
//        Connection conn = getConnection();
//
//        String insertQuery = "INSERT INTO my_entity(the_value) VALUES (?)";
//
//        PreparedStatement pre =  getConnection().prepareStatement(insertQuery);
//        pre.setString(1, myEntity.theValue());
//        pre.execute();
//
//    }
//
//    public List<MyEntity> list() throws SQLException {
//        List<MyEntity> myent = new ArrayList<>();
//        Connection conn = getConnection();
//
//        PreparedStatement pre = conn.prepareStatement("SELECT * FROM my_entity");
//        ResultSet rs = pre.executeQuery();
//
//        while(rs.next()){
//            myent.add(new MyEntity(rs.getLong(1), rs.getString(2)));
//        }
//
//        return myent;
//
//    }

    public void delete() throws SQLException {
        Connection conn = getConnection();
        conn.prepareStatement("DELETE FROM my_entity");
    }

    public void InetAddress(InetAddress InetAddress) throws SQLException {

        Connection connection = getConnection();

        String sql = "INSERT INTO my_entity (the_value) VALUES (192.168.1.1)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        // Convert the LineString to Well-Known Text (WKT)
        String inet = InetAddress.toString();

        // Set the WKT string as a parameter
        preparedStatement.setString(1, inet);

        preparedStatement.executeUpdate();
    }
}
