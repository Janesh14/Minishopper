package com.techatpark.practices;

import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.testcontainers.containers.PostgreSQLContainer;

import java.util.List;
public class PostgresExtension implements BeforeAllCallback, ExtensionContext.Store.CloseableResource{

    private static PostgreSQLContainer postgresqlContainer = new PostgreSQLContainer("postgres:latest");

    @Override
    public void beforeAll(ExtensionContext context) {
        if( !postgresqlContainer.isRunning()) {
            postgresqlContainer.withDatabaseName("postgres");
            postgresqlContainer.withUsername("postgres");
            postgresqlContainer.withPassword("postgres123");
            postgresqlContainer.withInitScript("init.sql");
            postgresqlContainer.setPortBindings(List.of("5432:5432"));
            postgresqlContainer.start();
        }
    }

    @Override
    public void close() {
        if(postgresqlContainer.isRunning()) {
            postgresqlContainer.stop();
        }
    }
}