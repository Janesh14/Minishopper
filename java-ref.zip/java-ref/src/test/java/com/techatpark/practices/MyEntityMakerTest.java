package com.techatpark.practices;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.InetAddress;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MyEntityMakerTest {

    private MyEntityMaker entityMaker;

    @BeforeEach
    void setUp() {
        entityMaker = new MyEntityMaker();
    }

    @AfterEach
    void tearDown() {
        try {
            entityMaker.delete();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Test
    void testCreate() throws SQLException {
        MyEntityMaker entityMaker = new MyEntityMaker();
        entityMaker.create();
        entityMaker.getClass();
     entityMaker.My_data(4);


    }
}
