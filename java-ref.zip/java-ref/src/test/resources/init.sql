DROP TABLE IF EXISTS my_entity;

CREATE TABLE my_entity(
id SERIAL NOT NULL,
the_value POINT,
the_circle circle,
line_value LINE
PRIMARY KEY(id)
);