package com.example.model;

import org.junit.jupiter.api.BeforeEach;

class LoginInputTest {

    private LoginInput loginInputUnderTest;

    @BeforeEach
    void setUp() {
        loginInputUnderTest = new LoginInput();
    }
}
