package com.example.controller;

import com.example.model.LoginDetails;
import com.example.model.LoginInput;
import com.example.services.LoginService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@ExtendWith(SpringExtension.class)
@WebMvcTest(MiniController.class)
class MiniControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LoginService mockLoginService;

    @Test
    void testUserReg() throws Exception {
        // Setup
        when(mockLoginService.save(any(LoginDetails.class))).thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/v1/register")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUserLogin() throws Exception {
        // Setup
        when(mockLoginService.login(any(LoginInput.class))).thenReturn(new HashMap<>());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/v1/login")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
