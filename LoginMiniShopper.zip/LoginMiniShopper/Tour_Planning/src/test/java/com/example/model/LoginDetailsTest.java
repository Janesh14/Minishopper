package com.example.model;

import org.junit.jupiter.api.BeforeEach;

class LoginDetailsTest {

    private LoginDetails loginDetailsUnderTest;

    @BeforeEach
    void setUp() {
        loginDetailsUnderTest = new LoginDetails();
    }
}
