package com.example.impl;

import com.example.model.LoginDetails;
import com.example.model.LoginInput;
import com.example.repository.LoginRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoginServiceImplTest {

    @Mock
    private LoginRepository mockLoginRepo;

    @InjectMocks
    private LoginServiceImpl loginServiceImplUnderTest;

    @Test
    void testSave() {
        // Setup
        final LoginDetails loginDetails = new LoginDetails();
        loginDetails.setId(0);
        loginDetails.setFirstName("firstName");
        loginDetails.setLastName("lastName");
        loginDetails.setUserName("userName");
        loginDetails.setPassword("password");
        loginDetails.setEmailId("emailId");
        loginDetails.setCreatedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        loginDetails.setMobile(0L);
        loginDetails.setAddress_line1("address_line1");
        loginDetails.setStreet("street");
        loginDetails.setState("state");
        loginDetails.setPincode("pincode");

        when(mockLoginRepo.existsByUserName("userName")).thenReturn(false);

        // Configure LoginRepository.save(...).
        final LoginDetails loginDetails1 = new LoginDetails();
        loginDetails1.setId(0);
        loginDetails1.setFirstName("firstName");
        loginDetails1.setLastName("lastName");
        loginDetails1.setUserName("userName");
        loginDetails1.setPassword("password");
        loginDetails1.setEmailId("emailId");
        loginDetails1.setCreatedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        loginDetails1.setMobile(0L);
        loginDetails1.setAddress_line1("address_line1");
        loginDetails1.setStreet("street");
        loginDetails1.setState("state");
        loginDetails1.setPincode("pincode");
       // when(mockLoginRepo.save(any(LoginDetails.class))).thenReturn(loginDetails1);

        // Run the test
        final ResponseEntity<Object> result = loginServiceImplUnderTest.save(loginDetails);

        // Verify the results
       // verify(mockLoginRepo).save(any(LoginDetails.class));
    }

    @Test
    void testLogin() {
        // Setup
        final LoginInput loginInput = new LoginInput();
        loginInput.setUserName("userName");
        loginInput.setPassword("password");

        // Configure LoginRepository.findByUserName(...).
        final LoginDetails loginDetails = new LoginDetails();
        loginDetails.setId(0);
        loginDetails.setFirstName("firstName");
        loginDetails.setLastName("lastName");
        loginDetails.setUserName("userName");
        loginDetails.setPassword("password");
        loginDetails.setEmailId("emailId");
        loginDetails.setCreatedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        loginDetails.setMobile(0L);
        loginDetails.setAddress_line1("address_line1");
        loginDetails.setStreet("street");
        loginDetails.setState("state");
        loginDetails.setPincode("pincode");
        //when(mockLoginRepo.findByUserName("userName")).thenReturn(loginDetails);

        // Run the test
        final Map<String, Object> result = loginServiceImplUnderTest.login(loginInput);

        // Verify the results
    }

    @Test
    void testLogin_LoginRepositoryReturnsNull() {
        // Setup
        final LoginInput loginInput = new LoginInput();
        loginInput.setUserName("userName");
        loginInput.setPassword("password");

        when(mockLoginRepo.findByUserName("userName")).thenReturn(null);

        // Run the test
        final Map<String, Object> result = loginServiceImplUnderTest.login(loginInput);

        // Verify the results
    }

    @Test
    void testEmailValid() {
        assertThat(loginServiceImplUnderTest.emailValid("email")).isFalse();
    }

    @Test
    void testMobileValid() {
        assertThat(loginServiceImplUnderTest.mobileValid(0L)).isFalse();
    }
}
