package com.example.controller;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.model.LoginDetails;
import com.example.model.LoginInput;
import com.example.services.LoginService;

@RestController

@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping("/api/v1")
public class MiniController {

	@Autowired
	private LoginService loginService;

	@PostMapping("/register")
	public ResponseEntity<Object> userReg(@RequestBody LoginDetails loginDetails) {
		return loginService.save(loginDetails);
	}

	@PostMapping("/login")
	public Map<String, Object> userLogin(@RequestBody LoginInput loginInput) {
		return loginService.login(loginInput);
	}
	
}
