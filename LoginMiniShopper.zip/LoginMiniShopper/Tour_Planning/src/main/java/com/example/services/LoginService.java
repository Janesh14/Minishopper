package com.example.services;

import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.example.model.LoginDetails;
import com.example.model.LoginInput;

public interface LoginService {

	ResponseEntity<Object> save(LoginDetails loginDetails);
	
	Map<String, Object> login(LoginInput loginInput);
}
	

	
	

