package com.example.impl;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.model.LoginDetails;
import com.example.model.LoginInput;
import com.example.repository.LoginRepository;
import com.example.services.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginRepository loginRepo;

	@Override
	public ResponseEntity<Object> save(LoginDetails loginDetails) {

		String userName = loginDetails.getUserName();

		String email = loginDetails.getEmailId();
		long mobile = loginDetails.getMobile();
		loginDetails.setCreatedDate(new Date(System.currentTimeMillis()));
		if (loginRepo.existsByUserName(userName)) {
			return new ResponseEntity<Object>(
					"Error: This " + loginDetails.getUserName() + " UserName already taken!..", HttpStatus.BAD_REQUEST);
		}

		else if (!emailValid(email)) {
			return new ResponseEntity<Object>("Error: Email Id is Not valid", HttpStatus.BAD_REQUEST);
		}
		if (!mobileValid(mobile)) {
			return new ResponseEntity<Object>("Error: Mobile Number is Not valid", HttpStatus.BAD_REQUEST);
		} else {
			loginRepo.save(loginDetails);
			return new ResponseEntity<Object>(loginDetails, HttpStatus.OK);
		}
	}

	@Override
	public Map<String, Object> login(LoginInput loginInput) {

		LoginDetails loginDetails = loginRepo.findByUserName(loginInput.getUserName());
		Map<String, Object> response = new HashMap<>();
		if (loginDetails == null) {
			response.put("ResponseStatus", Boolean.FALSE);
		} else if (loginDetails.getUserName().equals(loginInput.getUserName())
				&& loginDetails.getPassword().equals(loginInput.getPassword())) {

			response.put("ResponseStatus", Boolean.TRUE);

		} else {
			response.put("ResponseStatus", Boolean.FALSE);
		}
		return response;
	}

	public boolean emailValid(String email) {
		String regex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
		Pattern pat = Pattern.compile(regex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	public boolean mobileValid(long number) {
		Pattern pat = Pattern.compile("^\\d{10}$");
		String phone = Long.toString(number);
		if (phone == null)
			return false;
		return pat.matcher(phone).matches();
	}

}
