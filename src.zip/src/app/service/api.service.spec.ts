import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { ApiService } from './api.service';

describe('ApiService', () => {
  let service: ApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ApiService]
    });
    service = TestBed.inject(ApiService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('getProduct', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      service.getProduct().subscribe(res => {
        expect(res).toEqual("id");
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8083/itemdetails/api/v2/itemdetails'
      );
      expect(req.request.method).toEqual('GET');
      req.flush("id");
      httpTestingController.verify();
    });
  });
});
