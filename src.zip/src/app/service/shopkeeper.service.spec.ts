import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { ShopkeeperService } from './shopkeeper.service';

describe('ShopkeeperService', () => {
  let service: ShopkeeperService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ShopkeeperService]
    });
    service = TestBed.inject(ShopkeeperService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('getOrdereditems', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      service.getOrdereditems().subscribe((res: any) => {
        expect(res).toEqual("id");
      });
      const req = httpTestingController.expectOne('http://localhost:8082/OrderDetails/api/v1/getorders');
      expect(req.request.method).toEqual('GET');
      req.flush("id");
      httpTestingController.verify();
    });
  });
  describe('deleteOrdereditems', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      service.deleteOrdereditems(1).subscribe((res: any) => {
        expect(res).toEqual("id");
      });
      const req = httpTestingController.expectOne('http://localhost:8082/OrderDetails/api/v1/deleteorders/1');
      expect(req.request.method).toEqual('DELETE');
      req.flush("id");
      httpTestingController.verify();
    });
  });
});
