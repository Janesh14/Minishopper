import { TestBed } from '@angular/core/testing';
import { CartService } from './cart.service';

describe('CartService', () => {
  let service: CartService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [CartService] });
    service = TestBed.inject(CartService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  it(`cartItemList has default value`, () => {
    expect(service.cartItemList).toEqual([]);
  });

  describe('getProducts', () => {

    it('makes expected calls', () => {


      service.getProducts().subscribe((res: any) => {

        expect(res).toEqual([]);

      });
    });
  });


  describe('addtoCart', () => {

    it('makes expected calls', () => {


      service.addtoCart(1)
    });
  });


  describe('removeCartItem', () => {

    it('makes expected calls', () => {


      service.removeCartItem(1)
    });
  });

  describe('removeAllCart', () => {

    it('makes expected calls', () => {


      service.removeAllCart()
    });
  });

  describe('setProduct', () => {

    it('makes expected calls', () => {


      service.setProduct(1)



    });
  });
});

