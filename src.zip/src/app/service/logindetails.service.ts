import { Injectable } from "@angular/core";



@Injectable()
export class LoginDetails {
  id: number;
  firstName: string;
  lastName: string;
  emailId: string;
  password: string;
  createdDate: Date;
  mobile: number;
  address_line1: string;
  street: string;
  state: string;
  pincode: string;
  userName: string;
}

