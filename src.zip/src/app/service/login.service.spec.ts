import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { LoginService } from './login.service';
import { LoginDetails } from './logindetails.service';

describe('LoginService', () => {
  let service: LoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [LoginService]
    });
    service = TestBed.inject(LoginService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });
  describe('doReg', () => {

    it('makes expected calls', () => {

      const httpTestingController = TestBed.inject(HttpTestingController);

      service.doReg(LoginDetails).subscribe((res: any) => {

        expect(res).toEqual("Id");

      });

      const req = httpTestingController.expectOne('http://localhost:8080/minishopper/api/v1/register');

      expect(req.request.method).toEqual('POST');

      req.flush("Id");

      httpTestingController.verify();

    });

  });
  describe('doLogin', () => {

    it('makes expected calls', () => {

      const httpTestingController = TestBed.inject(HttpTestingController);

      service.doLogin(LoginDetails).subscribe((res: any) => {

        expect(res).toEqual("Id");

      });

      const req = httpTestingController.expectOne('http://localhost:8080/minishopper/api/v1/login');

      expect(req.request.method).toEqual('POST');

      req.flush("Id");

      httpTestingController.verify();

    });

  });

  describe('addOrder', () => {

    it('makes expected calls', () => {

      const httpTestingController = TestBed.inject(HttpTestingController);

      service.addOrder([]).subscribe((res: any) => {

        expect(res).toEqual("Id");

      });

      const req = httpTestingController.expectOne('http://localhost:8082/OrderDetails/api/v1/addorders');

      expect(req.request.method).toEqual('POST');

      req.flush("Id");

      httpTestingController.verify();

    });

  });
});
