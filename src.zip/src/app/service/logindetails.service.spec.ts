import { TestBed } from "@angular/core/testing";
import { LoginDetails } from "./logindetails.service";

describe("LoginDetails", () => {
  let service: LoginDetails;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [LoginDetails] });
    service = TestBed.inject(LoginDetails);
  });

  it("can load instance", () => {
    expect(service).toBeTruthy();
  });
});
