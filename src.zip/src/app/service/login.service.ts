import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { item } from '../model/items';
import { LoginDetails } from './logindetails.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
login: Observable<LoginDetails>[];
private baseUrl ='http://localhost:8080/minishopper/api/v1'
private orderUrl='http://localhost:8082/OrderDetails/api/v1'
  constructor(private http: HttpClient) { }
  doReg(LoginDetails: object): Observable<object> {

    return this.http.post(`${this.baseUrl}/register`, LoginDetails);

  }
  doLogin(credentials: object): Observable<object> {

    return this.http.post(`${this.baseUrl}/login`, credentials);
  
  }
  addOrder(order: item[]):Observable<object> {

    return this.http.post(`${this.orderUrl}/addorders`,order );

}
}
