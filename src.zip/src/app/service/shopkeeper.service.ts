import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Orders } from '../model/orders';

@Injectable({
  providedIn: 'root'
})
export class ShopkeeperService {
  private baseUrl='http://localhost:8082/OrderDetails/api/v1'
  private delUrl= 'http://localhost:8082/OrderDetails/api/v1'
  constructor(private http: HttpClient) { }
  getOrdereditems(): any {

    return this.http.get(`${this.baseUrl}/getorders`)

  }
  deleteOrdereditems(id: number): Observable<any> {

    return this.http.delete(`${this.delUrl}/deleteorders/${id}`, { responseType: 'text' });

  }
}
