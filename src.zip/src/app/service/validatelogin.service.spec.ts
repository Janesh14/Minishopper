import { TestBed } from '@angular/core/testing';
import { ValidateloginService } from './validatelogin.service';

describe('ValidateloginService', () => {
  let service: ValidateloginService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [ValidateloginService] });
    service = TestBed.inject(ValidateloginService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('userLogin', () => {

    it('makes expected calls', () => {


      service.userLogin()


    });
  });
  describe('login', () => {

    it('makes expected calls', () => {


      service.login()


    });
  });

  describe('logout', () => {

    it('makes expected calls', () => {


      service.logout()


    });
  });



});
