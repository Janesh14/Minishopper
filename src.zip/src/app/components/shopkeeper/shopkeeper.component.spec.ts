import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { ShopkeeperService } from 'src/app/service/shopkeeper.service';
import { ShopkeeperComponent } from './shopkeeper.component';

describe('ShopkeeperComponent', () => {
  let component: ShopkeeperComponent;
  let fixture: ComponentFixture<ShopkeeperComponent>;

  beforeEach(() => {
    const activatedRouteStub = () => ({});
    const routerStub = () => ({});
    const shopkeeperServiceStub = () => ({
      getOrdereditems: () => ({ subscribe: (f: (arg0: {}) => any) => f({}) }),
      deleteOrdereditems: (id: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [ShopkeeperComponent],
      providers: [
        { provide: ActivatedRoute, useFactory: activatedRouteStub },
        { provide: Router, useFactory: routerStub },
        { provide: ShopkeeperService, useFactory: shopkeeperServiceStub }
      ]
    });
    fixture = TestBed.createComponent(ShopkeeperComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const shopkeeperServiceStub: ShopkeeperService = fixture.debugElement.injector.get(
        ShopkeeperService
      );
      spyOn(shopkeeperServiceStub, 'getOrdereditems').and.callThrough();
      component.ngOnInit();
      expect(shopkeeperServiceStub.getOrdereditems).toHaveBeenCalled();
    });
  });

  describe('reload', () => {
    it('makes expected calls', () => {
      const shopkeeperServiceStub: ShopkeeperService = fixture.debugElement.injector.get(
        ShopkeeperService
      );
      spyOn(shopkeeperServiceStub, 'getOrdereditems').and.callThrough();
      component.reload();
      expect(shopkeeperServiceStub.getOrdereditems).toHaveBeenCalled();
    });
  });

  describe('delete', () => {

    it('makes expected calls', () => {

      const shopkeeperServiceStub: ShopkeeperService = fixture.debugElement.injector.get(

        ShopkeeperService

      );

      spyOn(shopkeeperServiceStub, 'deleteOrdereditems');

      component.delete(1);

    });

  });

  describe('fullfill', () => {

    it('makes expected calls', () => {

      component.fullfill();

    });

  });
});
