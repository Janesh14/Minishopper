import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Orders } from 'src/app/model/orders';
import { ShopkeeperService } from 'src/app/service/shopkeeper.service';

@Component({
  selector: 'app-shopkeeper',
  templateUrl: './shopkeeper.component.html',
  styleUrls: ['./shopkeeper.component.css']
})
export class ShopkeeperComponent implements OnInit {
  Orders: Orders[];
  id: number
  appList: any

  constructor(private shopkeeperService: ShopkeeperService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.shopkeeperService.getOrdereditems()
      .subscribe((data: any) => {
        console.log(data)
        this.Orders = data;
      }, (error: any) => console.log(error));
  }

  delete(id: number) {

    this.shopkeeperService.deleteOrdereditems(id).subscribe(data => {

      console.log(data);

      window.alert('Order Rejected Successfuly');

      window.location.reload();

    });

  }

  reload() {

    this.Orders = this.shopkeeperService.getOrdereditems()

    console.log('list:', this.Orders);
    console.log(this.Orders);

  }
  fullfill() {
    window.alert('Orders Fullfilled');
  }
}



