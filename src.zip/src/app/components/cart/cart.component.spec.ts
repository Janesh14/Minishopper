import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from 'src/app/service/cart.service';
import { LoginService } from 'src/app/service/login.service';
import { RouterTestingModule } from '@angular/router/testing';
import { CartComponent } from './cart.component';

describe('CartComponent', () => {
  let component: CartComponent;
  let fixture: ComponentFixture<CartComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({});
    const routerStub = () => ({});
    const cartServiceStub = () => ({
      getProducts: () => ({ subscribe: (f: (arg0: {}) => any) => f({}) }),
      getTotalPrice: () => ({}),
      removeCartItem: (item: any) => ({}),
      removeAllCart: () => ({})
    });
    const loginServiceStub = () => ({
      addOrder: (products: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [CartComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: CartService, useFactory: cartServiceStub },
        { provide: LoginService, useFactory: loginServiceStub }
      ]
    });
    fixture = TestBed.createComponent(CartComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`products has default value`, () => {
    expect(component.products).toEqual([]);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const cartServiceStub: CartService = fixture.debugElement.injector.get(
        CartService
      );
      spyOn(cartServiceStub, 'getProducts').and.callThrough();
      spyOn(cartServiceStub, 'getTotalPrice').and.callThrough();
      component.ngOnInit();
      expect(cartServiceStub.getProducts).toHaveBeenCalled();
      expect(cartServiceStub.getTotalPrice).toHaveBeenCalled();
    });
  });

  describe('onCheckout', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      spyOn(loginServiceStub, 'addOrder').and.callThrough();
      component.onCheckout();
      expect(loginServiceStub.addOrder).toHaveBeenCalled();
    });
  });

  describe('emptycart', () => {
    it('makes expected calls', () => {
      const cartServiceStub: CartService = fixture.debugElement.injector.get(
        CartService
      );
      spyOn(cartServiceStub, 'removeAllCart').and.callThrough();
      component.emptycart();
      expect(cartServiceStub.removeAllCart).toHaveBeenCalled();
    });
  });

  describe('removeItem', () => {
    it('makes expected calls', () => {
      const cartServiceStub: CartService = fixture.debugElement.injector.get(
        CartService
      );
      spyOn(cartServiceStub, 'removeCartItem');
      component.removeItem("");
    });
  });

});
