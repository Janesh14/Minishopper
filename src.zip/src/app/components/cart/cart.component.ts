import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from 'src/app/service/cart.service';
import { LoginService } from 'src/app/service/login.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  orderForm: FormGroup
  public products: any = [];
  public grandTotal !: number;
  constructor(private cartService: CartService, private fb: FormBuilder, private loginService: LoginService, private router: Router) { }

  ngOnInit(): void {
    this.cartService.getProducts()
      .subscribe(res => {
        this.products = res;
        console.log("prod", this.products);
        this.grandTotal = this.cartService.getTotalPrice();
      })

  }
  onCheckout() {


    this.loginService.addOrder(this.products).subscribe({
      next: (data: any) => {
        console.log(data);
        window.alert('Your order Placed Sucessfully');
      }
    });

  }
  removeItem(item: any) {
    this.cartService.removeCartItem(item);
  }

  emptycart() {
    this.cartService.removeAllCart();
  }
}





