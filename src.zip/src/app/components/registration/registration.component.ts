import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/service/login.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],

})
export class RegistrationComponent implements OnInit {
  regForm: FormGroup
  msg: boolean = false;
  emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";

  constructor(private fb: FormBuilder, private loginService: LoginService, private router: Router) {
    this.regForm = this.fb.group({
      firstName: this.fb.control('', Validators.required),
      lastName: this.fb.control('', Validators.required),
      emailId: this.fb.control('', [Validators.required, Validators.pattern(this.emailPattern)]),
      password: this.fb.control('', [Validators.required, Validators.pattern("((?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,12})")]),
      mobile: this.fb.control('', [Validators.required, Validators.pattern("[0-9]{3}[0-9]{3}[0-9]{4}")]),
      address_line1: this.fb.control('', Validators.required),
      street: this.fb.control('', Validators.required),
      state: this.fb.control('', Validators.required),
      pincode: this.fb.control('', [Validators.required, Validators.pattern("[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}")]),
      userName: this.fb.control('', Validators.required)

    })
  }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.regForm.value);
    if (this.regForm.valid) {
      this.loginService.doReg(this.regForm.value).subscribe({
        next: (data: any) => {
          console.log(data);
          window.alert('Registered Sucessfully');
          this.router.navigate(['/']);

        },

        error: (error) => {

          console.log('Error msg: ', error.error);

          alert(error.error);

        }

      });

    } else {

      this.msg = true;

      window.alert('Please fill all required field');

    }

  }

  resetBtn() {
    this.regForm.reset();
    this.msg = false;
  }
  check(input: string) {
    return (this.regForm.get(input)?.errors?.['required'] && this.regForm.get(input)?.touched) || (this.regForm.get(input)?.errors?.['required'] && this.msg)
  }
  login() {

    this.router.navigate(['']);



  }
}
