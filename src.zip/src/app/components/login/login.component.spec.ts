import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/service/login.service';
import { ValidateloginService } from 'src/app/service/validatelogin.service';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({
      group: (object: any) => ({}),
      control: (string: any, required: any) => ({})
    });
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    const loginServiceStub = () => ({
      doLogin: (value: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    const validateloginServiceStub = () => ({
      login: () => ({}),
      userLogin: () => ({})
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [LoginComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: LoginService, useFactory: loginServiceStub },
        { provide: ValidateloginService, useFactory: validateloginServiceStub }
      ]
    });
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`msg has default value`, () => {
    expect(component.msg).toEqual(false);
  });

  describe('onSubmit', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      const validateloginServiceStub: ValidateloginService = fixture.debugElement.injector.get(
        ValidateloginService
      );
      spyOn(routerStub, 'navigate').and.callThrough();
      spyOn(loginServiceStub, 'doLogin').and.callThrough();
      spyOn(validateloginServiceStub, 'login').and.callThrough();
      spyOn(validateloginServiceStub, 'userLogin').and.callThrough();
      component.onSubmit();
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(loginServiceStub.doLogin).toHaveBeenCalled();
      expect(validateloginServiceStub.login).toHaveBeenCalled();
      expect(validateloginServiceStub.userLogin).toHaveBeenCalled();

    
    });
  });

  describe('reg', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.reg();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });

  describe('ngOnInit', () => {

    it('makes expected calls', () => {

      component.ngOnInit();

    });

  });

  describe('check', () => {

    it('makes expected calls', () => {

      const loginServiceStub: ValidateloginService = fixture.debugElement.injector.get(

        ValidateloginService

      );

      spyOn(loginServiceStub, 'login').and.callThrough();

      component.check("");

      expect(loginServiceStub.login).toHaveBeenCalled();

     

    });

  });
});
