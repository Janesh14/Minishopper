import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/service/login.service';
import { ValidateloginService } from 'src/app/service/validatelogin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any
  msg: boolean = false;
  loginForm: FormGroup

  constructor(private fb: FormBuilder, private router: Router, private loginService: LoginService, public validateloginService: ValidateloginService) { 

    this.loginForm = this.fb.group({
      userName: this.fb.control('', Validators.required),
      password: this.fb.control('', Validators.required)
    })
  }
   

  ngOnInit(): void {
  }
  onSubmit() {
    if (this.loginForm.valid) {
      console.log('loginDetails: ', this.loginForm.value)
      this.loginService.doLogin(this.loginForm.value).subscribe(data => {
        console.log(data);
        this.result = Object.values(data);
        
        if (this.result[0] == true) {
          this.validateloginService.login();
          if (this.result[1] == "user") {
            this.validateloginService.userLogin();
            
          } 
          this.router.navigate(['/products'])
        } else {
          window.alert('Please Enter Valid UserName and Password');
        }
      })
    } else {
      this.msg = true;
    }
  }

  check(input: string) {
    return (this.loginForm.get(input)?.invalid && this.loginForm.get(input)?.touched) || (this.loginForm.get(input)?.invalid && this.msg)
  }

  reg() {
    this. router. navigate(['/reg']);
    
  }
//   products() {
//     this. router. navigate(['/products']);
 
// }
}

