import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';
import { CartService } from 'src/app/service/cart.service';
import { LoginService } from 'src/app/service/login.service';
import { ProductsComponent } from './products.component';

describe('ProductsComponent', () => {
  let component: ProductsComponent;
  let fixture: ComponentFixture<ProductsComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({});
    const routerStub = () => ({});
    const apiServiceStub = () => ({
      getProduct: () => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    const cartServiceStub = () => ({
      search: { subscribe: (f: (arg0: {}) => any) => f({}) },
      addtoCart: (item: any) => ({})
    });
    const loginServiceStub = () => ({});
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [ProductsComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: ApiService, useFactory: apiServiceStub },
        { provide: CartService, useFactory: cartServiceStub },
        { provide: LoginService, useFactory: loginServiceStub }
      ]
    });
    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const apiServiceStub: ApiService = fixture.debugElement.injector.get(
        ApiService
      );
      spyOn(apiServiceStub, 'getProduct').and.callThrough();
      component.ngOnInit();
      expect(apiServiceStub.getProduct).toHaveBeenCalled();
    });
  });

  describe('addtocart', () => {
    it('makes expected calls', () => {
      const apiServiceStub: ApiService = fixture.debugElement.injector.get(
        ApiService
      );
     spyOn(apiServiceStub, 'getProduct');

      component.addtocart("");
    });
  });
});
