
export class item {
  ItemName: string;
  Price: number;
  Quantity: number;
  Total: number;
  placedDate: Date;

}
