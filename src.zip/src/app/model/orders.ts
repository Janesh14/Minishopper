export class Orders {
  id: number;
  itemName: string;
  price: number;
  quantity: number;
  total: number;
  placedDate: Date;

}