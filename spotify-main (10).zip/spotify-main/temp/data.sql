INSERT INTO user_profile (id,username, first_name, last_name, number, date_of_birth, email)
VALUES (1,'sampleUsername', 'John', 'Doe', 123456789, '1990-01-01', 'john.doe@example.com');
