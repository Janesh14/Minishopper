package com.spotify.musicservice.dto;

import lombok.Data;

@Data
public class Images {
    private String url;
    private int height;
    private int width;

    // Getters and setters
}

