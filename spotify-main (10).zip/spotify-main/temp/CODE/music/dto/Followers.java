package com.spotify.musicservice.dto;

import lombok.Data;

@Data
public class Followers {
    private String href;
    private int total;

    // Getters and setters
}
