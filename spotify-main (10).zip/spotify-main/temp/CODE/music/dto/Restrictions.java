package com.spotify.musicservice.dto;

import lombok.Data;

@Data
public class Restrictions {
    private String reason;

    // Getters and setters
}

