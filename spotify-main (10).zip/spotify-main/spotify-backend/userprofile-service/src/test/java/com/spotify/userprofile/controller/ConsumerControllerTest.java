package com.spotify.userprofile.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConsumerControllerTest {

    @Test
    void consumeLogin() {
    }
}