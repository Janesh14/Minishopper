package com.spotify.userprofile.filter;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JWTFilterTest {

    @Test
    void doFilterInternal() {
    }
}