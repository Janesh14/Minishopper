package com.spotify.userprofile.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserProfileDtoTest {

    @Test
    void getUsername() {
    }

    @Test
    void getFirstName() {
    }

    @Test
    void getLastName() {
    }

    @Test
    void getPassword() {
    }

    @Test
    void getNumber() {
    }

    @Test
    void getDateOfBirth() {
    }

    @Test
    void getEmail() {
    }

    @Test
    void setUsername() {
    }

    @Test
    void setFirstName() {
    }

    @Test
    void setLastName() {
    }

    @Test
    void setPassword() {
    }

    @Test
    void setNumber() {
    }

    @Test
    void setDateOfBirth() {
    }

    @Test
    void setEmail() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}