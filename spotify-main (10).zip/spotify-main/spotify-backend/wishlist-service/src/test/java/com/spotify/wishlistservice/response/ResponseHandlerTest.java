package com.spotify.wishlistservice.response;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ResponseHandlerTest {

    @Test
    void generateResponse() {
    }
}