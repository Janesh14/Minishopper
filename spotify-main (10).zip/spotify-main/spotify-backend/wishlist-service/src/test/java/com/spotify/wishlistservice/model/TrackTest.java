package com.spotify.wishlistservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TrackTest {

    @Test
    void getAlbum() {
    }

    @Test
    void getArtists() {
    }

    @Test
    void getExternalUrls() {
    }

    @Test
    void getHref() {
    }

    @Test
    void getId() {
    }

    @Test
    void getName() {
    }

    @Test
    void getPreviewUrl() {
    }

    @Test
    void getType() {
    }

    @Test
    void getUri() {
    }

    @Test
    void setAlbum() {
    }

    @Test
    void setArtists() {
    }

    @Test
    void setExternalUrls() {
    }

    @Test
    void setHref() {
    }

    @Test
    void setId() {
    }

    @Test
    void setName() {
    }

    @Test
    void setPreviewUrl() {
    }

    @Test
    void setType() {
    }

    @Test
    void setUri() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}