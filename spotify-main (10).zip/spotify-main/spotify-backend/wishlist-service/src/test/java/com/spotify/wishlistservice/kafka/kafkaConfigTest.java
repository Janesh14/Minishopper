package com.spotify.wishlistservice.kafka;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class kafkaConfigTest {

    @Test
    void newTopic() {
    }
}