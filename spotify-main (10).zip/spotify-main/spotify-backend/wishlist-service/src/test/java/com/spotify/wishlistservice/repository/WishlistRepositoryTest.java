package com.spotify.wishlistservice.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WishlistRepositoryTest {

    @Test
    void deleteTrackByUsernameAndTracksId() {
    }
}