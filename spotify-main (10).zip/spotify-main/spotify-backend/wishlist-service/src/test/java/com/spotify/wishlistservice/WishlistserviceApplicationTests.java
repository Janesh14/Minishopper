package com.spotify.wishlistservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishlistserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
