package com.spotify.wishlistservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArtistTest {

    @Test
    void getExternalUrls() {
    }

    @Test
    void getHref() {
    }

    @Test
    void getId() {
    }

    @Test
    void getName() {
    }

    @Test
    void getType() {
    }

    @Test
    void getUri() {
    }

    @Test
    void setExternalUrls() {
    }

    @Test
    void setHref() {
    }

    @Test
    void setId() {
    }

    @Test
    void setName() {
    }

    @Test
    void setType() {
    }

    @Test
    void setUri() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}