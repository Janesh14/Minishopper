package com.spotify.wishlistservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WishlistTest {

    @Test
    void getUsername() {
    }

    @Test
    void getTracks() {
    }

    @Test
    void setUsername() {
    }

    @Test
    void setTracks() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}