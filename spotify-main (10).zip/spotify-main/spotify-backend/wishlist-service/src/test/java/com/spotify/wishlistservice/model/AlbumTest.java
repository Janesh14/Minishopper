package com.spotify.wishlistservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AlbumTest {

    @Test
    void getAlbumType() {
    }

    @Test
    void getArtists() {
    }

    @Test
    void getExternalUrls() {
    }

    @Test
    void getHref() {
    }

    @Test
    void getId() {
    }

    @Test
    void getImages() {
    }

    @Test
    void getName() {
    }

    @Test
    void getReleaseDate() {
    }

    @Test
    void getType() {
    }

    @Test
    void getUri() {
    }

    @Test
    void setAlbumType() {
    }

    @Test
    void setArtists() {
    }

    @Test
    void setExternalUrls() {
    }

    @Test
    void setHref() {
    }

    @Test
    void setId() {
    }

    @Test
    void setImages() {
    }

    @Test
    void setName() {
    }

    @Test
    void setReleaseDate() {
    }

    @Test
    void setType() {
    }

    @Test
    void setUri() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}