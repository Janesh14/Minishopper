package com.spotify.wishlistservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ImageTest {

    @Test
    void getHeight() {
    }

    @Test
    void getUrl() {
    }

    @Test
    void getWidth() {
    }

    @Test
    void setHeight() {
    }

    @Test
    void setUrl() {
    }

    @Test
    void setWidth() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}