package com.spotify.musicservice.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SpotifyControllerTest {

    @Test
    void getSpotifyAccessToken() {
    }

    @Test
    void getBillBoard100Playlist() {
    }

    @Test
    void getTodayTopHitsPlaylist() {
    }

    @Test
    void getDiscoverWeeklyPlaylist() {
    }

    @Test
    void getTrack() {
    }

    @Test
    void search() {
    }
}