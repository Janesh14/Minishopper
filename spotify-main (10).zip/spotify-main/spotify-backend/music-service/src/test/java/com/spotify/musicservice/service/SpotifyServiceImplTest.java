package com.spotify.musicservice.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SpotifyServiceImplTest {

    @Test
    void getSpotifyAccessToken() {
    }

    @Test
    void getBillBoard100Playlist() {
    }

    @Test
    void getTodayTopHitsPlaylist() {
    }

    @Test
    void getDiscoverWeeklyPlaylist() {
    }

    @Test
    void getTrack() {
    }

    @Test
    void search() {
    }
}