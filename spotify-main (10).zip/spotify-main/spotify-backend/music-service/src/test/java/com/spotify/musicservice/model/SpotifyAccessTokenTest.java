package com.spotify.musicservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SpotifyAccessTokenTest {

    @Test
    void getId() {
    }

    @Test
    void getAccessToken() {
    }

    @Test
    void getTokenType() {
    }

    @Test
    void getExpiresIn() {
    }

    @Test
    void setId() {
    }

    @Test
    void setAccessToken() {
    }

    @Test
    void setTokenType() {
    }

    @Test
    void setExpiresIn() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}