import { Component } from '@angular/core';

@Component({
  selector: 'app-today-top-hits-playlist',
  templateUrl: './today-top-hits-playlist.component.html',
  styleUrls: ['./today-top-hits-playlist.component.css']
})
export class TodayTopHitsPlaylistComponent {

}
