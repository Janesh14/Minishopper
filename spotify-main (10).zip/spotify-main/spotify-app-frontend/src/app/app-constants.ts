export const API_URL = "http://localhost:9090/api/v1.0/"
export const API_URL_AUTH = "http://localhost:9090/api/v1.0/auth"
export const API_URL_MUSIC = "http://localhost:8901/api/v1.0/music"