export class Image{
    constructor(
        public height: number,
        public url: String,
        public width: number,

    ) { }
}