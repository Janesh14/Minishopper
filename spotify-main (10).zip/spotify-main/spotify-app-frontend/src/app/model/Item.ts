import { Track } from './Track';
export class Item{
    constructor(
        public addedAt:string,
        public track:Track
    ){}
}