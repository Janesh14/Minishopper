import { Item } from './Item';
export class Tracks{
    constructor(
        public items: Item[]
    ) {}
}