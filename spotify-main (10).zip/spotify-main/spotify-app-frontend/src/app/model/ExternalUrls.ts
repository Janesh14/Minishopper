export class ExternalUrls{
    constructor(
        public spotify: string
    ) {}
}