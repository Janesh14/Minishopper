# spotify
Music Application That lists the sound tracks for a particular user, allows users to search for music tracks, and save tracks to favorites.
