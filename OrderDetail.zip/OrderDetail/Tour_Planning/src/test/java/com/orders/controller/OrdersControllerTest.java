package com.orders.controller;

import com.orders.model.OrderDetails;
import com.orders.repository.OrderRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(OrdersController.class)
class OrdersControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderRepository mockOrderRepository;

    @Test
    void testGetAllOrders() throws Exception {
        // Setup
        // Configure OrderRepository.findAll(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final List<OrderDetails> orderDetails = Arrays.asList(orderDetails1);
        when(mockOrderRepository.findAll()).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v1/getorders")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testGetAllOrders_OrderRepositoryReturnsNoItems() throws Exception {
        // Setup
        when(mockOrderRepository.findAll()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v1/getorders")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testCreateOrderDetail() throws Exception {
        // Setup
        // Configure OrderRepository.saveAll(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final List<OrderDetails> orderDetails = Arrays.asList(orderDetails1);
        when(mockOrderRepository.saveAll(Arrays.asList(new OrderDetails()))).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/v1/addorders")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testCreateOrderDetail_OrderRepositoryReturnsNoItems() throws Exception {
        // Setup
        when(mockOrderRepository.saveAll(Arrays.asList(new OrderDetails()))).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/v1/addorders")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testDeleteOrderDetail() throws Exception {
        // Setup
        // Configure OrderRepository.findById(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final Optional<OrderDetails> orderDetails = Optional.of(orderDetails1);
        when(mockOrderRepository.findById(0)).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v1/deleteorders/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
      //  assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
       // verify(mockOrderRepository).delete(any(OrderDetails.class));
    }

    @Test
    void testDeleteOrderDetail_OrderRepositoryFindByIdReturnsAbsent() throws Exception {
        // Setup
        when(mockOrderRepository.findById(0)).thenReturn(Optional.empty());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v1/deleteorders/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDeleteOrderDetail_ThrowsResourceNotFoundException() throws Exception {
        // Setup
        // Configure OrderRepository.findById(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final Optional<OrderDetails> orderDetails = Optional.of(orderDetails1);
        when(mockOrderRepository.findById(0)).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/v1/deleteorders/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
       // verify(mockOrderRepository).delete(any(OrderDetails.class));
    }

    @Test
    void testDetailsOrderDetails() throws Exception {
        // Setup
        // Configure OrderRepository.findById(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final Optional<OrderDetails> orderDetails = Optional.of(orderDetails1);
        when(mockOrderRepository.findById(0)).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v1/getorder/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDetailsOrderDetails_OrderRepositoryReturnsAbsent() throws Exception {
        // Setup
        when(mockOrderRepository.findById(0)).thenReturn(Optional.empty());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v1/getorder/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDetailsOrderDetails_ThrowsResourceNotFoundException() throws Exception {
        // Setup
        // Configure OrderRepository.findById(...).
        final OrderDetails orderDetails1 = new OrderDetails();
        orderDetails1.setId(0);
        orderDetails1.setPlacedDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        orderDetails1.setItemName("itemName");
        orderDetails1.setQuantity(0);
        orderDetails1.setPrice(0);
        orderDetails1.setTotal(0L);
        final Optional<OrderDetails> orderDetails = Optional.of(orderDetails1);
        when(mockOrderRepository.findById(0)).thenReturn(orderDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/v1/getorder/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
