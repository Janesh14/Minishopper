package com.orders.impl;

import com.orders.model.OrderDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OrderServiceImplTest {

    private OrderServiceImpl orderServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        orderServiceImplUnderTest = new OrderServiceImpl();
    }

    @Test
    void testSave() {
        assertThat(orderServiceImplUnderTest.save(new OrderDetails())).isNull();
    }
}
