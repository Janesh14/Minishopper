package com.orders.model;

import org.junit.jupiter.api.BeforeEach;

class OrderDetailsTest {

    private OrderDetails orderDetailsUnderTest;

    @BeforeEach
    void setUp() {
        orderDetailsUnderTest = new OrderDetails();
    }
}
