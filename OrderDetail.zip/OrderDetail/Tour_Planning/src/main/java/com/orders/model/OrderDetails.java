package com.orders.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "Orders")
public class OrderDetails {

	@Id
	@SequenceGenerator(initialValue = 101, name = "Id")
	@GeneratedValue(generator = "Id")
	private int id;
	
	
	private String ItemName;
	
	private int Quantity;
	private int Price;
	private long Total;
	@Column(name = "PLACED_DATE", columnDefinition = "DATE")
	private java.sql.Date placedDate;

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	

	

	

	public java.sql.Date getPlacedDate() {
		return placedDate;
	}

	public void setPlacedDate(java.sql.Date placedDate) {
		this.placedDate = placedDate;
	}

	

	public String getItemName() {
		return ItemName;
	}

	public void setItemName(String itemName) {
		ItemName = itemName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public long getTotal() {
		return Total;
	}

	public void setTotal(long total) {
		Total = total;
	}
	
}




