package com.orders.impl;

import org.springframework.http.ResponseEntity;

import com.orders.model.OrderDetails;
import com.orders.service.OrderService;


  public class OrderServiceImpl implements OrderService {
  
  @Override 
  public ResponseEntity<Object> save(OrderDetails orderDetails) { 
 
  return null; }
  
  
  }
 
