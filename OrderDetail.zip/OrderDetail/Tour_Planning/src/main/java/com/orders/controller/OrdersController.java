package com.orders.controller;

import java.sql.Date;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orders.exception.ResourceNotFoundException;
import com.orders.model.OrderDetails;
import com.orders.repository.OrderRepository;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/v1")
public class OrdersController {

	@Autowired
	OrderRepository orderRepository;

	@GetMapping("/getorders")
	public List<OrderDetails> getAllOrders() {
		return orderRepository.findAll();
	}

	@PostMapping("/addorders")
	
	public List<OrderDetails> createOrderDetail(@RequestBody List<OrderDetails> orderDetails){
		for(int itr=0;itr< orderDetails.size(); itr++){
			orderDetails.get(itr).setPlacedDate(new Date(System.currentTimeMillis()));
		}
		
		return orderRepository.saveAll(orderDetails);
		
	}

	@DeleteMapping("/deleteorders/{id}")
	public Map<String, Boolean> deleteOrderDetail(@PathVariable(value = "id") int OrderId)
			throws ResourceNotFoundException {
		OrderDetails orderDetails = orderRepository.findById(OrderId)
				.orElseThrow(() -> new ResourceNotFoundException("Order not found for this id:: " + OrderId));
		orderRepository.delete(orderDetails);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@GetMapping("/getorder/{id}")
	public ResponseEntity<OrderDetails> detailsOrderDetails(@PathVariable(value = "id") int OrderId)
			throws ResourceNotFoundException {
		OrderDetails orderDetails = orderRepository.findById(OrderId)
				.orElseThrow(() -> new ResourceNotFoundException("Order not found for this ID:: " + OrderId));
		return ResponseEntity.ok().body(orderDetails);
	}
}