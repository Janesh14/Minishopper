package com.orders.service;

import org.springframework.http.ResponseEntity;

import com.orders.model.OrderDetails;



public interface OrderService {
	ResponseEntity<Object> save(OrderDetails orderDetails);

}
