package com.parent.app.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ParentDetailsTestTest {

    private ParentDetailsTest parentDetailsTestUnderTest;

    @BeforeEach
    void setUp() {
        parentDetailsTestUnderTest = new ParentDetailsTest();
    }

    @Test
    void testSetUp() {
        // Setup
        // Run the test
        parentDetailsTestUnderTest.setUp();

        // Verify the results
    }
}
