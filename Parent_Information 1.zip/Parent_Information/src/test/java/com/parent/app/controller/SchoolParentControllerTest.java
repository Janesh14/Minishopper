package com.parent.app.controller;

import com.parent.app.model.ParentDetails;
import com.parent.app.service.ParentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SchoolParentController.class)
class SchoolParentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ParentService mockParentService;

    @Test
    void testGetAllParentDetails() throws Exception {
        // Setup
        // Configure ParentService.listDetails(...).
        final ParentDetails parentDetails1 = new ParentDetails();
        parentDetails1.setId("id");
        parentDetails1.setStudentName("studentName");
        parentDetails1.setParentName("parentName");
        parentDetails1.setAddress("address");
        parentDetails1.setState("state");
        parentDetails1.setCountry("country");
        parentDetails1.setCity("city");
        parentDetails1.setZipCode("zipCode");
        parentDetails1.setEmailId("emailId");
        parentDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentDetails1.setPrimaryMobile("primaryMobile");
        parentDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentDetails1.setSecondaryMobile("secondaryMobile");
        parentDetails1.setRegisterDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        final List<ParentDetails> parentDetails = List.of(parentDetails1);
        when(mockParentService.listDetails()).thenReturn(parentDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/details/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testGetAllParentDetails_ParentServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockParentService.listDetails()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/details/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testGetParentDetails() throws Exception {
        // Setup
        when(mockParentService.getParentDetail("Id")).thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/details/get/{id}", "Id")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testCreateParentDetails() throws Exception {
        // Setup
        when(mockParentService.save(any(ParentDetails.class))).thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/details/add")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUpdateParentDetails() throws Exception {
        // Setup
        when(mockParentService.updateParentDetail(eq("Id"), any(ParentDetails.class)))
                .thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/details/update/{id}", "Id")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testApproveParentDetails() throws Exception {
        // Setup
        when(mockParentService.approveParentDetail(eq("Id"), any(ParentDetails.class)))
                .thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/details/approved/{id}", "Id")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        //assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testDeleteParentDetails() throws Exception {
        // Setup
        when(mockParentService.deleteParentDetail("Id")).thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(delete("/api/details/delete/{id}", "Id")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
