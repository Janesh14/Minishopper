package com.parent.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ParentInformationApplicationTestsTest {

    private ParentInformationApplicationTests parentInformationApplicationTestsUnderTest;

    @BeforeEach
    void setUp() {
        parentInformationApplicationTestsUnderTest = new ParentInformationApplicationTests();
    }

    @Test
    void testContextLoads() {
        // Setup
        // Run the test
        parentInformationApplicationTestsUnderTest.contextLoads();

        // Verify the results
    }
}
