package com.parent.app.model;

import org.junit.jupiter.api.BeforeEach;

class ParentDetailsTest {

    private ParentDetails parentDetailsUnderTest;

    @BeforeEach
    void setUp() {
        parentDetailsUnderTest = new ParentDetails();
    }
}
