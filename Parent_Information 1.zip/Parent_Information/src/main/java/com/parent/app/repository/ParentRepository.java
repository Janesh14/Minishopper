package com.parent.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.parent.app.model.ParentDetails;

@Repository
public interface ParentRepository extends JpaRepository<ParentDetails, String> {

	ParentDetails findByEmailId(String emailId);
	
	boolean existsByEmailId(String emailId);

}
