package com.parent.app.controller;

import java.sql.Date;
import java.util.List;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.parent.app.model.ParentDetails;
import com.parent.app.service.ParentService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/details")
public class SchoolParentController {

		@Autowired
		private ParentService parentService;

		@GetMapping("/list")
		public List<ParentDetails> getAllParentDetails() {
			return parentService.listDetails();
		}
		
		@GetMapping("/get/{id}")
		public ResponseEntity<Object> getParentDetails(@PathVariable(value = "id") String Id) {
			return parentService.getParentDetail(Id);
		}

		@PostMapping("/add")
		public ResponseEntity<Object> createParentDetails( @RequestBody ParentDetails parentDetails) {
			parentDetails.setId("R"+new Random().nextInt(1111111111));
			parentDetails.setRegisterDate(new Date(System.currentTimeMillis()));
						return parentService.save(parentDetails);
		}

		@PutMapping("/update/{id}")
		public ResponseEntity<String> updateParentDetails(@PathVariable(value = "id") String Id,
				@RequestBody ParentDetails parentDetails) {
			return parentService.updateParentDetail(Id, parentDetails);
		}
		
		@PutMapping("/approved/{id}")
		public ResponseEntity<String> approveParentDetails(@PathVariable(value = "id") String Id,
				@RequestBody ParentDetails parentDetails) {
			return parentService.approveParentDetail(Id, parentDetails);
		}
		
		@DeleteMapping("/delete/{id}")
		public ResponseEntity<String> deleteParentDetails(@PathVariable(value = "id") String Id) {
			return parentService.deleteParentDetail(Id);
		}

	}


