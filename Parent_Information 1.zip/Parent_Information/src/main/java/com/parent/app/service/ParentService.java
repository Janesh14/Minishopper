package com.parent.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.parent.app.model.ParentDetails;


public interface ParentService {
	
	List<ParentDetails> listDetails();
	
	ResponseEntity<String> deleteParentDetail(String Id);

	ResponseEntity<Object> getParentDetail(String Id);
	
	ResponseEntity<Object> save(ParentDetails parentDetails);
	
	ResponseEntity<String> updateParentDetail(String Id, ParentDetails parentDetails);
	
	ResponseEntity<String> approveParentDetail(String Id, ParentDetails parentDetails);
}
