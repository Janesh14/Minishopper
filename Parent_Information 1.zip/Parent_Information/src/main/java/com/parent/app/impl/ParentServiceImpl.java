package com.parent.app.impl;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.parent.app.model.ParentDetails;
import com.parent.app.repository.ParentRepository;
import com.parent.app.service.ParentService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
	@Service
	public class ParentServiceImpl implements ParentService {

		@Autowired
		private ParentRepository parentRepo;
		
		@Override
		public ResponseEntity<Object> save(ParentDetails parentDetails){
			String emailID = parentDetails.getEmailId();
			if(parentRepo.existsByEmailId(emailID)) {
				return new ResponseEntity<Object>(
						"Error: This " + parentDetails.getEmailId() + " Email ID already Exists!...", HttpStatus.BAD_REQUEST);
			} else {
				parentRepo.save(parentDetails);
				return new ResponseEntity<Object>(parentDetails, HttpStatus.OK);
			}
		}

		@Override
		public List<ParentDetails> listDetails() {
			return parentRepo.findAll();
		}

		@Override
		public ResponseEntity<String> updateParentDetail(String Id, ParentDetails parentDetails) {
			ParentDetails updateParent = parentRepo.findById(Id).orElse(new ParentDetails());

			if (updateParent.getId() == Id) {
				updateParent.setStudentName(parentDetails.getStudentName());
				updateParent.setParentName(parentDetails.getParentName());
				updateParent.setAddress(parentDetails.getAddress());
				updateParent.setState(parentDetails.getState());
				updateParent.setCountry(parentDetails.getCountry());
				updateParent.setCity(parentDetails.getCity());
				updateParent.setZipCode(parentDetails.getZipCode());
				updateParent.setEmailId(parentDetails.getEmailId());
				updateParent.setPrimaryContactPersonName(parentDetails.getPrimaryContactPersonName());
				updateParent.setPrimaryMobile(parentDetails.getPrimaryMobile());
				updateParent.setSecondaryContactPersonName(parentDetails.getSecondaryContactPersonName());
				updateParent.setSecondaryMobile(parentDetails.getSecondaryMobile());
				log.info("updated value");
				parentRepo.save(updateParent);
				return new ResponseEntity<String>("Parent Details Updated successfully", HttpStatus.OK);
			} else {
				log.info("update value not found");
				return new ResponseEntity<String>("Error: Parent Details Not Found for ID: " + Id,
						HttpStatus.NOT_FOUND);
			}
		}

		@Override
		public ResponseEntity<String> approveParentDetail(String Id, ParentDetails parentDetails) {
			ParentDetails approveParent = parentRepo.findById(Id).orElse(new ParentDetails());
			
			if (approveParent.getId() == Id) {
				parentRepo.save(approveParent);
				return new ResponseEntity<String>("Approved successfully", HttpStatus.OK);
			}else {
				log.info("Approved value not found");
				return new ResponseEntity<String>("Error: Details Not Found for this ID: " + Id,
						HttpStatus.NOT_FOUND);
			}
		}	
		
		@Override
		public ResponseEntity<Object> getParentDetail(String Id) {
			ParentDetails parentDetails = parentRepo.findById(Id).orElse(new ParentDetails());

			if (parentDetails.getId() == Id) {
				log.info(" get parent details");
				return new ResponseEntity<Object>(parentDetails, HttpStatus.OK);
			} else {
				log.info("get value not found");
				return new ResponseEntity<Object>("Error: Parent Details Not Found this ID: " + Id,
						HttpStatus.NOT_FOUND);
			}
			
		}
		
		@Override
		public ResponseEntity<String> deleteParentDetail(String Id) {
			ParentDetails parentUpdateDetails = parentRepo.findById(Id).orElse(new ParentDetails());
			if (parentUpdateDetails.getId() == Id) {
				log.info("Rejected");
				parentRepo.delete(parentUpdateDetails);
				return new ResponseEntity<String>("Parent Details Rejected", HttpStatus.OK);
			} else {
				return new ResponseEntity<String>("Error: Parent Details Not Found for this ID: " + Id,
						HttpStatus.BAD_REQUEST);
			}
		}
}
