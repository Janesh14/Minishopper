package com.parent.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentInformationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentInformationApplication.class, args);
	}

}
