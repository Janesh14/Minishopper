package com.parent.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffCircularApplicationTests {

	@Test
	void contextLoads() {
	}

}
