package com.parent.app.controller;

import com.parent.app.model.CircularDetails;
import com.parent.app.repository.CircularRepository;
import com.parent.app.service.CircularService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(CircularController.class)
class CircularControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CircularService mockCircularService;
    @MockBean
    private CircularRepository mockCircularRepo;

    @Test
    void testGetAllCircularDetails() throws Exception {
        // Setup
        // Configure CircularService.listDetails(...).
        final CircularDetails circularDetails1 = new CircularDetails();
        circularDetails1.setCircularId(0);
        circularDetails1.setInformText("informText");
        circularDetails1.setPostedBy("postedBy");
        circularDetails1.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails1.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        final List<CircularDetails> circularDetails = List.of(circularDetails1);
        when(mockCircularService.listDetails()).thenReturn(circularDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/details/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testGetAllCircularDetails_CircularServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCircularService.listDetails()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/details/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testCreateCircularDetails() throws Exception {
        // Setup
        // Configure CircularService.addCircularDetail(...).
        final CircularDetails circularDetails = new CircularDetails();
        circularDetails.setCircularId(0);
        circularDetails.setInformText("informText");
        circularDetails.setPostedBy("postedBy");
        circularDetails.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(mockCircularService.addCircularDetail(any(CircularDetails.class))).thenReturn(circularDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(post("/api/details/add")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
      //  assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUpdateAckParentDetail() throws Exception {
        // Setup
        // Configure CircularRepository.findByCircularId(...).
        final CircularDetails circularDetails = new CircularDetails();
        circularDetails.setCircularId(0);
        circularDetails.setInformText("informText");
        circularDetails.setPostedBy("postedBy");
        circularDetails.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(mockCircularRepo.findByCircularId(0)).thenReturn(circularDetails);

        when(mockCircularService.updateAckParentDetail(0)).thenReturn(false);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/details/ack/{circularId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
