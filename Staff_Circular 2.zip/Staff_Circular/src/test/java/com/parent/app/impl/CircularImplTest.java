package com.parent.app.impl;

import com.parent.app.model.CircularDetails;
import com.parent.app.repository.CircularRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.OptimisticLockingFailureException;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CircularImplTest {

    @Mock
    private CircularRepository mockCircularRepo;

    @InjectMocks
    private CircularImpl circularImplUnderTest;

    @Test
    void testListDetails() {
        // Setup
        // Configure CircularRepository.findAll(...).
        final CircularDetails circularDetails1 = new CircularDetails();
        circularDetails1.setCircularId(0);
        circularDetails1.setInformText("informText");
        circularDetails1.setPostedBy("postedBy");
        circularDetails1.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails1.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        final List<CircularDetails> circularDetails = List.of(circularDetails1);
        when(mockCircularRepo.findAll()).thenReturn(circularDetails);

        // Run the test
        final List<CircularDetails> result = circularImplUnderTest.listDetails();

        // Verify the results
    }

    @Test
    void testListDetails_CircularRepositoryReturnsNoItems() {
        // Setup
        when(mockCircularRepo.findAll()).thenReturn(Collections.emptyList());

        // Run the test
        final List<CircularDetails> result = circularImplUnderTest.listDetails();

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testAddCircularDetail() {
        // Setup
        final CircularDetails circularDetails = new CircularDetails();
        circularDetails.setCircularId(0);
        circularDetails.setInformText("informText");
        circularDetails.setPostedBy("postedBy");
        circularDetails.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));

        // Configure CircularRepository.save(...).
        final CircularDetails circularDetails1 = new CircularDetails();
        circularDetails1.setCircularId(0);
        circularDetails1.setInformText("informText");
        circularDetails1.setPostedBy("postedBy");
        circularDetails1.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails1.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(mockCircularRepo.save(any(CircularDetails.class))).thenReturn(circularDetails1);

        // Run the test
        final CircularDetails result = circularImplUnderTest.addCircularDetail(circularDetails);

        // Verify the results
    }

    @Test
    void testAddCircularDetail_CircularRepositoryThrowsOptimisticLockingFailureException() {
        // Setup
        final CircularDetails circularDetails = new CircularDetails();
        circularDetails.setCircularId(0);
        circularDetails.setInformText("informText");
        circularDetails.setPostedBy("postedBy");
        circularDetails.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));

        when(mockCircularRepo.save(any(CircularDetails.class))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> circularImplUnderTest.addCircularDetail(circularDetails))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }

    @Test
    void testUpdateAckParentDetail() {
        // Setup
        // Configure CircularRepository.findById(...).
        final CircularDetails circularDetails1 = new CircularDetails();
        circularDetails1.setCircularId(0);
        circularDetails1.setInformText("informText");
        circularDetails1.setPostedBy("postedBy");
        circularDetails1.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails1.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        final Optional<CircularDetails> circularDetails = Optional.of(circularDetails1);
        when(mockCircularRepo.findById(0)).thenReturn(circularDetails);

        // Configure CircularRepository.save(...).
        final CircularDetails circularDetails2 = new CircularDetails();
        circularDetails2.setCircularId(0);
        circularDetails2.setInformText("informText");
        circularDetails2.setPostedBy("postedBy");
        circularDetails2.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails2.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(mockCircularRepo.save(any(CircularDetails.class))).thenReturn(circularDetails2);

        // Run the test
        final boolean result = circularImplUnderTest.updateAckParentDetail(0);

        // Verify the results
      //  assertThat(result).isFalse();
       // verify(mockCircularRepo).save(any(CircularDetails.class));
    }

    @Test
    void testUpdateAckParentDetail_CircularRepositoryFindByIdReturnsAbsent() {
        // Setup
        when(mockCircularRepo.findById(0)).thenReturn(Optional.empty());

        // Configure CircularRepository.save(...).
        final CircularDetails circularDetails = new CircularDetails();
        circularDetails.setCircularId(0);
        circularDetails.setInformText("informText");
        circularDetails.setPostedBy("postedBy");
        circularDetails.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(mockCircularRepo.save(any(CircularDetails.class))).thenReturn(circularDetails);

        // Run the test
        final boolean result = circularImplUnderTest.updateAckParentDetail(0);

        // Verify the results
       // assertThat(result).isFalse();
       // verify(mockCircularRepo).save(any(CircularDetails.class));
    }

    @Test
    void testUpdateAckParentDetail_CircularRepositorySaveThrowsOptimisticLockingFailureException() {
        // Setup
        // Configure CircularRepository.findById(...).
        final CircularDetails circularDetails1 = new CircularDetails();
        circularDetails1.setCircularId(0);
        circularDetails1.setInformText("informText");
        circularDetails1.setPostedBy("postedBy");
        circularDetails1.setNotifyDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        circularDetails1.setAcknowledgeDate(Date.valueOf(LocalDate.of(2020, 1, 1)));
        final Optional<CircularDetails> circularDetails = Optional.of(circularDetails1);
        when(mockCircularRepo.findById(0)).thenReturn(circularDetails);

        when(mockCircularRepo.save(any(CircularDetails.class))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> circularImplUnderTest.updateAckParentDetail(0))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }
}
