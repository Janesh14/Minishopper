package com.parent.app.model;

import org.junit.jupiter.api.BeforeEach;

class CircularDetailsTest {

    private CircularDetails circularDetailsUnderTest;

    @BeforeEach
    void setUp() {
        circularDetailsUnderTest = new CircularDetails();
    }
}
