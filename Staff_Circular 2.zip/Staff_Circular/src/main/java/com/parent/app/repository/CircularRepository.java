package com.parent.app.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.parent.app.model.CircularDetails;


@Repository
public interface CircularRepository extends JpaRepository<CircularDetails, Integer> {
	CircularDetails findByCircularId(int circularId);

	



}
