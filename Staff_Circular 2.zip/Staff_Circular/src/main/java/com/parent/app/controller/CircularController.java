package com.parent.app.controller;


import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.parent.app.model.CircularDetails;
import com.parent.app.repository.CircularRepository;
import com.parent.app.service.CircularService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/details")
public class CircularController {
	
	@Autowired
	private CircularService circularService;
	
	@Autowired
	private CircularRepository circularRepo;
	
	@GetMapping("/list")
	public List<CircularDetails> getAllCircularDetails() {
		return circularService.listDetails();
	}

	
	@PostMapping("/add")
	public CircularDetails createCircularDetails(@RequestBody CircularDetails circularDetials) {
		circularDetials.setNotifyDate(new Date(System.currentTimeMillis()));
		return circularService.addCircularDetail(circularDetials);
	}
	
	@PutMapping("/ack/{circularId}")
	public CircularDetails updateAckParentDetail(@PathVariable(value = "circularId") int circularId) {
	 CircularDetails circularDetails=circularRepo.findByCircularId(circularId);
	  boolean date =  circularService.updateAckParentDetail(circularId);
	  if(date==true) {
	 circularDetails.getAcknowledgeDate();
	  }
	return circularDetails;
	 
	}

}
