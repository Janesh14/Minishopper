package com.parent.app.impl;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.parent.app.model.CircularDetails;
import com.parent.app.repository.CircularRepository;
import com.parent.app.service.CircularService;


@Service
public class CircularImpl implements CircularService {
	
	@Autowired
	private CircularRepository circularRepo;
	
	@Override
	public List<CircularDetails> listDetails() {
		return circularRepo.findAll();	
	}
	
	@Override
	public CircularDetails addCircularDetail(CircularDetails circularDetails) {
		return circularRepo.save(circularDetails);
	}

	@Override
	public boolean updateAckParentDetail(int circularId) {
		CircularDetails ackParent = circularRepo.findById(circularId).orElse(new CircularDetails());

		if(ackParent.getCircularId() == circularId ) {
			boolean ack = true;
			ackParent.setAcknowledgeDate(new Date(System.currentTimeMillis()));
			circularRepo.save(ackParent);
			return ack;
		}
		return false;
	
	}

	
	
}
