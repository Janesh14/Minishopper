package com.parent.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.parent.app.model.ParentUpdateDetails;


@Repository
public interface UpdateRepository extends JpaRepository<ParentUpdateDetails, Integer> {

}
