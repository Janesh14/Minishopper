package com.parent.app.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.parent.app.model.ParentUpdateDetails;
import com.parent.app.repository.UpdateRepository;
import com.parent.app.service.UpdateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UpdateImpl implements UpdateService {
	
	@Autowired
	private UpdateRepository updateRepo;
	
	@Override
	public List<ParentUpdateDetails> listDetails() {
		return updateRepo.findAll();	
	}

	@Override
	public ResponseEntity<Object> getParentDetail(int Id) {
		ParentUpdateDetails parentUpdateDetails = updateRepo.findById(Id).orElse(new ParentUpdateDetails());

		if (parentUpdateDetails.getId() == Id) {
			log.info(" get parent details");
			return new ResponseEntity<Object>(parentUpdateDetails, HttpStatus.OK);
		} else {
			log.info("get value not found");
			return new ResponseEntity<Object>("Error: Parent Details Not Found for ID: " + Id,
					HttpStatus.NOT_FOUND);
		}

	}


	@Override
	public ResponseEntity<String> updateParentDetail(int Id, ParentUpdateDetails parentUpdateDetails) {
		ParentUpdateDetails updateParent = updateRepo.findById(Id).orElse(new ParentUpdateDetails());

		if (updateParent.getId() == Id) {
			updateParent.setStudentName(parentUpdateDetails.getStudentName());
			updateParent.setParentName(parentUpdateDetails.getParentName());
			updateParent.setAddress(parentUpdateDetails.getAddress());
			updateParent.setState(parentUpdateDetails.getState());
			updateParent.setCountry(parentUpdateDetails.getCountry());
			updateParent.setCity(parentUpdateDetails.getCity());
			updateParent.setZipCode(parentUpdateDetails.getZipCode());
			updateParent.setEmailId(parentUpdateDetails.getEmailId());
			updateParent.setPrimaryContactPersonName(parentUpdateDetails.getPrimaryContactPersonName());
			updateParent.setPrimaryMobile(parentUpdateDetails.getPrimaryMobile());
			updateParent.setSecondaryContactPersonName(parentUpdateDetails.getSecondaryContactPersonName());
			updateParent.setSecondaryMobile(parentUpdateDetails.getSecondaryMobile());
			log.info("updated value");
			updateRepo.save(updateParent);
			return new ResponseEntity<String>("Parent Details Updated successfully", HttpStatus.OK);
		} else {
			log.info("update value not found");
			return new ResponseEntity<String>("Error: Details Not Found for this ID: " + Id,
					HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public ResponseEntity<String> approveParentDetail(int Id, ParentUpdateDetails parentUpdateDetails) {
		ParentUpdateDetails approveParent = updateRepo.findById(Id).orElse(new ParentUpdateDetails());

		if (approveParent.getId() == Id) {
			updateRepo.save(approveParent);
			return new ResponseEntity<String>("Approved successfully", HttpStatus.OK);
		}else {
			log.info("Approved value not found");
			return new ResponseEntity<String>("Error: Parent Details Not Found this ID: " + Id,
					HttpStatus.NOT_FOUND);
		}
		
	}	
	
	@Override
	public ResponseEntity<String> rejectParentDetail(int Id, ParentUpdateDetails parentUpdateDetails) {
		ParentUpdateDetails rejectParent = updateRepo.findById(Id).orElse(new ParentUpdateDetails());

		if (rejectParent.getId() == Id) {
			log.info("Rejected");
			updateRepo.save(rejectParent);
			return new ResponseEntity<String>("Rejected", HttpStatus.OK);
		}else {
			log.info("Rejected value not found");
			return new ResponseEntity<String>("Error: Parent Details Not Found for this ID: " + Id,
					HttpStatus.NOT_FOUND);
		}
		
	}	
}
