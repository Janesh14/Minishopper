package com.parent.app.impl;

import com.parent.app.model.ParentUpdateDetails;
import com.parent.app.repository.UpdateRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UpdateImplTest {

    @Mock
    private UpdateRepository mockUpdateRepo;

    @InjectMocks
    private UpdateImpl updateImplUnderTest;

    @Test
    void testListDetails() {
        // Setup
        // Configure UpdateRepository.findAll(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        final List<ParentUpdateDetails> parentUpdateDetails = List.of(parentUpdateDetails1);
        when(mockUpdateRepo.findAll()).thenReturn(parentUpdateDetails);

        // Run the test
        final List<ParentUpdateDetails> result = updateImplUnderTest.listDetails();

        // Verify the results
    }

    @Test
    void testListDetails_UpdateRepositoryReturnsNoItems() {
        // Setup
        when(mockUpdateRepo.findAll()).thenReturn(Collections.emptyList());

        // Run the test
        final List<ParentUpdateDetails> result = updateImplUnderTest.listDetails();

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testGetParentDetail() {
        // Setup
        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails = Optional.of(parentUpdateDetails1);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails);

        // Run the test
        final ResponseEntity<Object> result = updateImplUnderTest.getParentDetail(0);

        // Verify the results
    }

    @Test
    void testGetParentDetail_UpdateRepositoryReturnsAbsent() {
        // Setup
        when(mockUpdateRepo.findById(0)).thenReturn(Optional.empty());

        // Run the test
        final ResponseEntity<Object> result = updateImplUnderTest.getParentDetail(0);

        // Verify the results
    }

    @Test
    void testUpdateParentDetail() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails3 = new ParentUpdateDetails();
        parentUpdateDetails3.setId(0);
        parentUpdateDetails3.setStudentName("studentName");
        parentUpdateDetails3.setParentName("parentName");
        parentUpdateDetails3.setAddress("address");
        parentUpdateDetails3.setState("state");
        parentUpdateDetails3.setCountry("country");
        parentUpdateDetails3.setCity("city");
        parentUpdateDetails3.setZipCode("zipCode");
        parentUpdateDetails3.setEmailId("emailId");
        parentUpdateDetails3.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails3.setPrimaryMobile("primaryMobile");
        parentUpdateDetails3.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails3.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails3);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.updateParentDetail(0, parentUpdateDetails);

        // Verify the results
       // assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testUpdateParentDetail_UpdateRepositoryFindByIdReturnsAbsent() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);
        when(mockUpdateRepo.findById(0)).thenReturn(Optional.empty());

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails1);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.updateParentDetail(0, parentUpdateDetails);

        // Verify the results
        //assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testUpdateParentDetail_UpdateRepositorySaveThrowsOptimisticLockingFailureException() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> updateImplUnderTest.updateParentDetail(0, parentUpdateDetails))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }

    @Test
    void testApproveParentDetail() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails3 = new ParentUpdateDetails();
        parentUpdateDetails3.setId(0);
        parentUpdateDetails3.setStudentName("studentName");
        parentUpdateDetails3.setParentName("parentName");
        parentUpdateDetails3.setAddress("address");
        parentUpdateDetails3.setState("state");
        parentUpdateDetails3.setCountry("country");
        parentUpdateDetails3.setCity("city");
        parentUpdateDetails3.setZipCode("zipCode");
        parentUpdateDetails3.setEmailId("emailId");
        parentUpdateDetails3.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails3.setPrimaryMobile("primaryMobile");
        parentUpdateDetails3.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails3.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails3);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.approveParentDetail(0, parentUpdateDetails);

        // Verify the results
       // assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testApproveParentDetail_UpdateRepositoryFindByIdReturnsAbsent() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);
        when(mockUpdateRepo.findById(0)).thenReturn(Optional.empty());

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails1);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.approveParentDetail(0, parentUpdateDetails);

        // Verify the results
        //assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testApproveParentDetail_UpdateRepositorySaveThrowsOptimisticLockingFailureException() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> updateImplUnderTest.approveParentDetail(0, parentUpdateDetails))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }

    @Test
    void testRejectParentDetail() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails3 = new ParentUpdateDetails();
        parentUpdateDetails3.setId(0);
        parentUpdateDetails3.setStudentName("studentName");
        parentUpdateDetails3.setParentName("parentName");
        parentUpdateDetails3.setAddress("address");
        parentUpdateDetails3.setState("state");
        parentUpdateDetails3.setCountry("country");
        parentUpdateDetails3.setCity("city");
        parentUpdateDetails3.setZipCode("zipCode");
        parentUpdateDetails3.setEmailId("emailId");
        parentUpdateDetails3.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails3.setPrimaryMobile("primaryMobile");
        parentUpdateDetails3.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails3.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails3);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.rejectParentDetail(0, parentUpdateDetails);

        // Verify the results
       // assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testRejectParentDetail_UpdateRepositoryFindByIdReturnsAbsent() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        final ResponseEntity<String> expectedResult = new ResponseEntity<>("body", HttpStatus.OK);
        when(mockUpdateRepo.findById(0)).thenReturn(Optional.empty());

        // Configure UpdateRepository.save(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenReturn(parentUpdateDetails1);

        // Run the test
        final ResponseEntity<String> result = updateImplUnderTest.rejectParentDetail(0, parentUpdateDetails);

        // Verify the results
      //  assertThat(result).isEqualTo(expectedResult);
        verify(mockUpdateRepo).save(any(ParentUpdateDetails.class));
    }

    @Test
    void testRejectParentDetail_UpdateRepositorySaveThrowsOptimisticLockingFailureException() {
        // Setup
        final ParentUpdateDetails parentUpdateDetails = new ParentUpdateDetails();
        parentUpdateDetails.setId(0);
        parentUpdateDetails.setStudentName("studentName");
        parentUpdateDetails.setParentName("parentName");
        parentUpdateDetails.setAddress("address");
        parentUpdateDetails.setState("state");
        parentUpdateDetails.setCountry("country");
        parentUpdateDetails.setCity("city");
        parentUpdateDetails.setZipCode("zipCode");
        parentUpdateDetails.setEmailId("emailId");
        parentUpdateDetails.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails.setPrimaryMobile("primaryMobile");
        parentUpdateDetails.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails.setSecondaryMobile("secondaryMobile");

        // Configure UpdateRepository.findById(...).
        final ParentUpdateDetails parentUpdateDetails2 = new ParentUpdateDetails();
        parentUpdateDetails2.setId(0);
        parentUpdateDetails2.setStudentName("studentName");
        parentUpdateDetails2.setParentName("parentName");
        parentUpdateDetails2.setAddress("address");
        parentUpdateDetails2.setState("state");
        parentUpdateDetails2.setCountry("country");
        parentUpdateDetails2.setCity("city");
        parentUpdateDetails2.setZipCode("zipCode");
        parentUpdateDetails2.setEmailId("emailId");
        parentUpdateDetails2.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails2.setPrimaryMobile("primaryMobile");
        parentUpdateDetails2.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails2.setSecondaryMobile("secondaryMobile");
        final Optional<ParentUpdateDetails> parentUpdateDetails1 = Optional.of(parentUpdateDetails2);
        when(mockUpdateRepo.findById(0)).thenReturn(parentUpdateDetails1);

        when(mockUpdateRepo.save(any(ParentUpdateDetails.class))).thenThrow(OptimisticLockingFailureException.class);

        // Run the test
        assertThatThrownBy(() -> updateImplUnderTest.rejectParentDetail(0, parentUpdateDetails))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }
}
