package com.parent.app.model;

import org.junit.jupiter.api.BeforeEach;

class ParentUpdateDetailsTest {

    private ParentUpdateDetails parentUpdateDetailsUnderTest;

    @BeforeEach
    void setUp() {
        parentUpdateDetailsUnderTest = new ParentUpdateDetails();
    }
}
