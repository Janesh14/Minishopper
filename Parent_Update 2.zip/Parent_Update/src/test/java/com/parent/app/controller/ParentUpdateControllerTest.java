package com.parent.app.controller;

import com.parent.app.model.ParentUpdateDetails;
import com.parent.app.service.UpdateService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ParentUpdateController.class)
class ParentUpdateControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UpdateService mockUpdateService;

    @Test
    void testGetAllParentDetails() throws Exception {
        // Setup
        // Configure UpdateService.listDetails(...).
        final ParentUpdateDetails parentUpdateDetails1 = new ParentUpdateDetails();
        parentUpdateDetails1.setId(0);
        parentUpdateDetails1.setStudentName("studentName");
        parentUpdateDetails1.setParentName("parentName");
        parentUpdateDetails1.setAddress("address");
        parentUpdateDetails1.setState("state");
        parentUpdateDetails1.setCountry("country");
        parentUpdateDetails1.setCity("city");
        parentUpdateDetails1.setZipCode("zipCode");
        parentUpdateDetails1.setEmailId("emailId");
        parentUpdateDetails1.setPrimaryContactPersonName("primaryContactPersonName");
        parentUpdateDetails1.setPrimaryMobile("primaryMobile");
        parentUpdateDetails1.setSecondaryContactPersonName("secondaryContactPersonName");
        parentUpdateDetails1.setSecondaryMobile("secondaryMobile");
        final List<ParentUpdateDetails> parentUpdateDetails = List.of(parentUpdateDetails1);
        when(mockUpdateService.listDetails()).thenReturn(parentUpdateDetails);

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
      //  assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testGetAllParentDetails_UpdateServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockUpdateService.listDetails()).thenReturn(Collections.emptyList());

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/list")
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("[]");
    }

    @Test
    void testGetParentDetails() throws Exception {
        // Setup
        when(mockUpdateService.getParentDetail(0)).thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(get("/api/get/{id}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
        assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testUpdateParentDetails() throws Exception {
        // Setup
        when(mockUpdateService.updateParentDetail(eq(0), any(ParentUpdateDetails.class)))
                .thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/update/{id}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
      //  assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testApproveParentDetails() throws Exception {
        // Setup
        when(mockUpdateService.approveParentDetail(eq(0), any(ParentUpdateDetails.class)))
                .thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/approved/{id}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
       // assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
        //assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }

    @Test
    void testRejectedParentDetails() throws Exception {
        // Setup
        when(mockUpdateService.rejectParentDetail(eq(0), any(ParentUpdateDetails.class)))
                .thenReturn(new ResponseEntity<>("body", HttpStatus.OK));

        // Run the test
        final MockHttpServletResponse response = mockMvc.perform(put("/api/rejected/{id}", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andReturn().getResponse();

        // Verify the results
      //  assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
       // assertThat(response.getContentAsString()).isEqualTo("expectedResponse");
    }
}
